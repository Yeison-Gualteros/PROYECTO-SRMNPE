import {Routes,Route,BrowserRouter,  } from 'react-router-dom';
import CandidatoEstudiante from './Components/CandidatoEstudiante'
import  EstudianteDocumentos from './Components/EstudianteDocumentos';
import Acudiente from './Components/Acudiente';
import Cupo from './Components/Cupo';
import DireccionAcudiente from './Components/DireccionAcudiente';
import Matricula from './Components/Matricula';
import PreMatricula from './Components/PreMatricula';
import Horarios from './Components/Horario';
 
function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path='/' exact element={<Cupo/>}></Route>
      <Route path='/' exact element={<CandidatoEstudiante/>}></Route>
      <Route path='/' exact element={<Horarios/>}></Route>
      <Route path='/' exact element={<PreMatricula/>}></Route>
      <Route path='/' exact element={<DireccionAcudiente/>}></Route>
      <Route path='/' exact element={<Matricula/>}></Route>
      <Route path='/' exact element={<Acudiente/>}></Route>
      <Route path='/' exact element={<EstudianteDocumentos/>}></Route>
      
    </Routes>
  </BrowserRouter>
  );
}

export default App;
