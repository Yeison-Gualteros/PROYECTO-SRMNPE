import React, { useEffect, useState } from 'react';
import '../Estilos.css';
import axios from 'axios';
import { show_alert } from '../functions';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';

const EstudianteDocumentos = () => {
  const url = 'https://localhost:5001/api/estudianteDocumentos';
  const [estudianteDocumentos, setEstudianteDocumentos] = useState([]);
  const [estudianteDocumentosId, setEstudianteDocumentosId] = useState('');
  const [nombreDocumento, setNombreDocumento] = useState('');
  const [tipoDocumento, setTipoDocumento] = useState('');
  const [numeroDocumento, setNumeroDocumento] = useState('');
  const [fechaActualizacion, setFechaActualizacion] = useState('');
  const [ubicacion, setUbicacion] = useState('');
  const [operation, setOperation] = useState(1);
  const [title, setTitle] = useState('');

  useEffect(() => {
    getEstudianteDocumentos();
  }, []);

  const getEstudianteDocumentos = async () => {
    try {
      const respuesta = await axios.get(url);
      setEstudianteDocumentos(respuesta.data);
    } catch (error) {
      show_alert('Error al obtener documentos', 'error');
    }
  };

  const openModal = (op, estudianteDocumentos) => {
    setOperation(op);
    if (op === 1) {
      setTitle('Registrar Estudiante');
      setEstudianteDocumentosId('');
      setNombreDocumento('');
      setTipoDocumento('');
      setNumeroDocumento('');
      setFechaActualizacion('');
      setUbicacion('');
    } else if (op === 2) {
      setTitle('Editar Documento');
      setEstudianteDocumentosId(estudianteDocumentos.estudianteDocumentosId);
      setNombreDocumento(estudianteDocumentos.nombreDocumento);
      setTipoDocumento(estudianteDocumentos.tipoDocumento);
      setNumeroDocumento(estudianteDocumentos.numeroDocumento);
      setFechaActualizacion(estudianteDocumentos.fechaActualizacion);
      setUbicacion(estudianteDocumentos.ubicacion);
    }
    window.setTimeout(function () {
      document.getElementById('NombreDocumento').focus();
    }, 500);
  };

  const validar = () => {
    if (nombreDocumento.trim() === '') {
      show_alert('¿Cuál es el nombre del documento que posees?', 'Escribe el nombre del documento');
    } else if (tipoDocumento === '') {
      show_alert('Escribe el tipo de documento que posees', 'Escribe el tipo de documento');
    } else if (numeroDocumento === '') {
      show_alert('Escribe el número de documento', 'Escribe el número de documento');
    } else if (fechaActualizacion === '') {
      show_alert('Escribe la fecha en la que se debe actualizar el documento', 'Escribe la fecha del documento, próximo a actualizar');
    } else if (ubicacion === '') {
      show_alert('Escribe la ubicación del documento', 'Escribe la ubicación del documento');
    } else {
      let parametros;
      let metodo;

      if (operation === 1) {
        parametros = { nombreDocumento, tipoDocumento, numeroDocumento, fechaActualizacion, ubicacion };
        metodo = 'POST';
      } else {
        parametros = { nombreDocumento, tipoDocumento, numeroDocumento, fechaActualizacion, ubicacion };
        metodo = 'PUT';
      }

      enviarSolicitud(metodo, parametros);
    }
  };

  const enviarSolicitud = async (metodo, parametros) => {
    try {
      if (metodo === 'POST') {
        await axios.post(`${url}`, parametros);
        show_alert('Documento añadido exitosamente', 'success');
        document.getElementById('btnCerrar').click();
        getEstudianteDocumentos();
      } else if (metodo === 'PUT') {
        await axios.put(`${url}/${estudianteDocumentosId}`, parametros); 
        show_alert('Documento editado con éxito', 'success');
        document.getElementById('btnCerrar').click();
        getEstudianteDocumentos();
      }
    } catch (error) {
      show_alert('Error en la solicitud', 'error');
      console.error(error);
    }
  };

  const deleteEstudianteDocumentos = (estudianteDocumentosId, nombreDocumento) => {
    const MySwal = withReactContent(Swal);
    MySwal.fire({
      title: `¿Seguro quieres eliminar el documento ${nombreDocumento}?`,
      icon: 'question',
      text: 'No se podrá deshacer esta acción',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await axios.delete(`${url}/${estudianteDocumentosId}`);
          show_alert('Documento eliminado exitosamente', 'success');
          getEstudianteDocumentos();
        } catch (error) {
          show_alert('Error al eliminar el documento', 'error');
          console.error(error);
        }
      } else {
        show_alert('El documento no fue eliminado', 'info');
      }
    });
  };

  return (
    <div className="App">
      <div className="container-fluid">
        <div className="row mt-3">
          <div className="col-md-4 offset-4">
            <div className="d-gris mx-auto">
              <div className="d-flex justify-content-center align-items-center h-100">
                <button
                  onClick={() => openModal(1)}
                  className="btn btn-primary"
                  data-bs-toggle="modal"
                  data-bs-target="#modalEstudianteDocumentos"
                >
                  <i className="fa-solid fa-circle-plus"></i> Añadir Documento nuevo
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-12 col-lg-8 offset-0 offset-lg-2">
            <div className="table-responsive">
              <table className="table table-bordered">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>DOCUMENTOSID</th>
                    <th>NOMBRE DOCUMENTO</th>
                    <th>TIPO DE DOCUMENTO</th>
                    <th>NUMERO DE DOCUMENTO</th>
                    <th>FECHA DE ACTUALIZACION</th>
                    <th>UBICACION</th>
                    <th>UPDATE/DELETE</th>
                  </tr>
                </thead>
                <tbody className="table-group-divider">
                  {estudianteDocumentos.map((documento, i) => (
                    <tr key={documento.estudianteDocumentosId}>
                      <td>{i + 1}</td>
                      <td>{documento.estudianteDocumentosId}</td>
                      <td>{documento.nombreDocumento}</td>
                      <td>{documento.tipoDocumento}</td>
                      <td>{documento.numeroDocumento}</td>
                      <td>{documento.fechaActualizacion}</td>
                      <td>{documento.ubicacion}</td>
                      <td>
                        <button
                          onClick={() => openModal(2, documento)}
                          className="btn btn-warning"
                          data-bs-toggle="modal"
                          data-bs-target="#modalEstudianteDocumentos"
                        >
                          <i className="fa-solid fa-edit"></i>
                        </button>
                        &nbsp;
                        <button
                          onClick={() => deleteEstudianteDocumentos(documento.estudianteDocumentosId, documento.nombreDocumento)}
                          className="btn btn-danger"
                        >
                          <i className="fa-solid fa-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <div id="modalEstudianteDocumentos" className="modal fade" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">{title}</h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <input type="hidden" id="estudianteDocumentosId" />
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="NombreDocumento"
                  className="form-control"
                  placeholder="NOMBRE DEL DOCUMENTO"
                  value={nombreDocumento}
                  onChange={(e) => setNombreDocumento(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="TipoDocumento"
                  className="form-control"
                  placeholder="TIPO DE DOCUMENTO"
                  value={tipoDocumento}
                  onChange={(e) => setTipoDocumento(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="NumeroDocumento"
                  className="form-control"
                  placeholder="NUMERO DE DOCUMENTO"
                  value={numeroDocumento}
                  onChange={(e) => setNumeroDocumento(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="FechaActualizacion"
                  className="form-control"
                  placeholder="FECHA DE ACTUALIZACION"
                  value={fechaActualizacion}
                  onChange={(e) => setFechaActualizacion(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="Ubicacion"
                  className="form-control"
                  placeholder="UBICACION DEL DOCUMENTO"
                  value={ubicacion}
                  onChange={(e) => setUbicacion(e.target.value)}
                />
              </div>
              <div className="d-grid col-6 mx-auto">
                <button onClick={() => validar()} className="btn btn-success">
                  Guardar
                </button>
              </div>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                id="btnCerrar"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EstudianteDocumentos;