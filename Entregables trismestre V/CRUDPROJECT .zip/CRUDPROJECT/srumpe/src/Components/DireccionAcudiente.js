import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';

const DireccionAcudiente = () => {
  const url = 'https://localhost:5001/api/direccionAcudiente';
  const [direccionAcudiente, setDireccionAcudiente] = useState([]);
  const [direccionAcudienteId, setDireccionAcudienteId] = useState('');
  const [calle, setCalle] = useState('');
  const [coloniaBarrio, setColoniaBarrio] = useState('');
  const [codigoPostal, setCodigoPostal] = useState('');
  const [pais, setPais] = useState('');
  const [operation, setOperation] = useState(1);
  const [title, setTitle] = useState('');

  useEffect(() => {
    getDireccionAcudiente();
  }, []);

  const getDireccionAcudiente = async () => {
    try {
      const response = await axios.get(url);
      setDireccionAcudiente(response.data);
    } catch (error) {
      console.error('Error fetching direccionAcudiente:', error);
    }
  };

  const openModal = (op, DireccionAcudienteItem) => {
    setOperation(op);
    if (op === 1) {
      setTitle('Registrar Dirección');
      setDireccionAcudienteId('');
      setCalle('');
      setColoniaBarrio('');
      setCodigoPostal('');
      setPais('');
    } else if (op === 2) {
      setTitle('Editar dirección');
      setDireccionAcudienteId(DireccionAcudienteItem.direccionAcudienteId);
      setCalle(DireccionAcudienteItem.calle);
      setColoniaBarrio(DireccionAcudienteItem.coloniaBarrio);
      setCodigoPostal(DireccionAcudienteItem.codigoPostal);
      setPais(DireccionAcudienteItem.pais);
    }
  };

  const validar = () => {
    if (calle.trim() === '') {
      mostrarAlerta('Escribe la calle del acudiente', 'error');
    } else if (coloniaBarrio.trim() === '') {
      mostrarAlerta('Escribe la colonia o barrio del acudiente', 'error');
    } else if (codigoPostal.trim() === '') {
      mostrarAlerta('Escribe el código postal del acudiente', 'error');
    } else if (pais.trim() === '') {
      mostrarAlerta('Escribe el país del acudiente', 'error');
    } else {
      const parametros = {
        calle,
        coloniaBarrio,
        codigoPostal,
        pais,
      };
      const metodo = operation === 1 ? 'POST' : 'PUT';
      enviarSolicitud(metodo, parametros);
    }
  };
  const enviarSolicitud = async () => {
    try {
      let response;
      if (operation === 1) {
        // Si la operación es 1, se trata de una solicitud POST
        const parametros = {
          calle,
          coloniaBarrio,
          codigoPostal,
          pais,
        };
        response = await axios.post(url, parametros);
        mostrarAlerta('Dirección añadida exitosamente', 'success');
      } else if (operation === 2) {
        // Si la operación es 2, se trata de una solicitud PUT
        const parametros = {
          direccionAcudienteId,
          calle,
          coloniaBarrio,
          codigoPostal,
          pais,
        };
        response = await axios.put(`${url}/${direccionAcudienteId}`, parametros);
        mostrarAlerta('Dirección editada exitosamente', 'success');
      }
      document.getElementById('btnCerrar').click();
      getDireccionAcudiente();
    } catch (error) {
      mostrarAlerta('Error de solicitud', 'error');
      
    }
  };
  const deleteDireccionAcudiente = (direccionAcudienteId, calle) => {
    const MySwal = withReactContent(Swal);
    MySwal.fire({
      title: `¿Seguro quieres eliminar la dirección de ${calle}?`,
      icon: 'question',
      text: 'No se podrá deshacer',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await axios.delete(`${url}/${direccionAcudienteId}`);
          mostrarAlerta('Dirección eliminada exitosamente', 'success');
          getDireccionAcudiente();
        } catch (error) {
          mostrarAlerta('Error al eliminar la dirección', 'error');
          console.error(error);
        }
      } else {
        mostrarAlerta('La dirección no fue eliminada', 'info');
      }
    });
  };

  const mostrarAlerta = (mensaje, tipo) => {
    Swal.fire({
      title: mensaje,
      icon: tipo,
    });
  };

  return (
    <div className="App">
      <div className="container-fluid">
        <div className="row mt-3">
          <div className="col-md-4 offset-4">
            <div className="d-gris mx-auto">
              <div className="d-flex justify-content-center align-items-center h-100">
                <button
                  onClick={() => openModal(1)}
                  className="btn btn-primary"
                  data-bs-toggle="modal"
                  data-bs-target="#modalDireccionAcudiente"
                >
                  <i className="fa-solid fa-circle-plus"></i> Añadir Dirección nueva
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-12 col-lg-8 offset-0 offset-lg-2">
            <div className="table-responsive">
              <table className="table table-bordered">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>DIRECCIONID</th>
                    <th>CALLE</th>
                    <th>COLONIA DEL BARRIO</th>
                    <th>CÓDIGO POSTAL</th>
                    <th>PAÍS</th>
                    <th>UPDATE/DELETE</th>
                  </tr>
                </thead>
                <tbody className="table-group-divider">
                  {direccionAcudiente.map((DireccionAcudienteItem, i) => (
                    <tr key={DireccionAcudienteItem.direccionAcudienteId}>
                      <td>{i + 1}</td>
                      <td>{DireccionAcudienteItem.direccionAcudienteId}</td>
                      <td>{DireccionAcudienteItem.calle}</td>
                      <td>{DireccionAcudienteItem.coloniaBarrio}</td>
                      <td>{DireccionAcudienteItem.codigoPostal}</td>
                      <td>{DireccionAcudienteItem.pais}</td>
                      <td>
                        <button
                          onClick={() => openModal(2, DireccionAcudienteItem)}
                          className="btn btn-warning"
                          data-bs-toggle="modal"
                          data-bs-target="#modalDireccionAcudiente"
                        >
                          <i className="fa-solid fa-edit"></i>
                        </button>
                        &nbsp;
                        <button
                          onClick={() =>
                            deleteDireccionAcudiente(
                              DireccionAcudienteItem.direccionAcudienteId,DireccionAcudienteItem.calle
                            )
                          }
                          className="btn btn-danger"
                        >
                          <i className="fa-solid fa-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              </div>
          </div>
        </div>
      </div>
      <div id="modalDireccionAcudiente" className="modal fade" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">{title}</h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <input type="hidden" id="direccionAcudienteId" />
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="Calle"
                  className="form-control"
                  placeholder="CALLE"
                  value={calle}
                  onChange={(e) => setCalle(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="ColoniaBarrio"
                  className="form-control"
                  placeholder="COLONIA DEL BARRIO"
                  value={coloniaBarrio}
                  onChange={(e) => setColoniaBarrio(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="CodigoPostal"
                  className="form-control"
                  placeholder="CÓDIGO POSTAL"
                  value={codigoPostal}
                  onChange={(e) => setCodigoPostal(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="Pais"
                  className="form-control"
                  placeholder="PAÍS"
                  value={pais}
                  onChange={(e) => setPais(e.target.value)}
                />
              </div>
              <div className="d-grid col-6 mx-auto">
                <button onClick={() => validar()} className="btn btn-success">
                  Guardar
                </button>
              </div>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                id="btnCerrar"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DireccionAcudiente;