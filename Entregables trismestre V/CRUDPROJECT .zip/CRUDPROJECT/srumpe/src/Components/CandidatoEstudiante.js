import React, { useEffect, useState } from 'react';
import '../Estilos.css';
import axios from 'axios';
import { show_alert } from '../functions';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';

const CandidatoEstudiante = () => {
  const url = 'https://localhost:5001/api/candidatoEstudiante';
  const [candidatoEstudiante, setCandidatoEstudiante] = useState([]);
  const [candidatoEstudianteId, setCandidatoEstudianteId] = useState('');
  const [nombre, setNombre] = useState('');
  const [apellido, setApellido] = useState('');
  const [operation, setOperations] = useState(1);
  const [title, setTitle] = useState('');
  const Url = `https://localhost:5001/api/candidatoEstudiante/${candidatoEstudianteId}`;


  useEffect(() => {
    getCandidatoEstudiante();
  }, []);

  const getCandidatoEstudiante = async () => {
    const respuesta = await axios.get(url);
    setCandidatoEstudiante(respuesta.data);
  };

  const openModal = (op, candidatoEstudiante) => {
    setOperations(op);
    if (op === 1) {
      setTitle('Registrar Estudiante');
      setCandidatoEstudianteId('');
      setNombre('');
      setApellido('');
    } else if (op === 2) {
      setTitle('Editar Estudiante');
      setCandidatoEstudianteId(candidatoEstudiante.candidatoEstudianteId);
      setNombre(candidatoEstudiante.nombre);
      setApellido(candidatoEstudiante.apellido);
    }
    window.setTimeout(function () {
      document.getElementById('Nombre').focus();
    }, 500);
  };

  const validar = () => {
    if (nombre.trim() === "") {
      show_alert("Escribe el nombre del estudiante", "Escribe el nombre del nombre");
    } else if (apellido === "") {
      show_alert("Escribe el apellido del estudiante", "Escribe el estado del apellido");
    } else {
      let parametros;
      let metodo;

      if (operation === 1) {
        parametros = { nombre: nombre, apellido: apellido };
        metodo = "POST";
        
      } else {
        parametros = { nombre: nombre, apellido: apellido };
        metodo = "PUT";
      }

      enviarSolicitud(metodo, parametros);
    }
  };

  const enviarSolicitud = async (metodo, parametros) => {
    if (metodo === "POST") {
      axios
        .post(`${url}`, parametros)
        .then(function (respuesta) {
          show_alert("Estudiante añadido exitosamente", "success");
          document.getElementById("btnCerrar").click();
          getCandidatoEstudiante();
        })
        .catch(function (error) {
          show_alert("error", "Error de solucitud");
          console.log(error);
        });
    } else if (metodo === "PUT") {
      axios
        .put(`${url}/${candidatoEstudianteId}`, parametros)
        .then(function (respuesta) {
          console.log("Solicitud PUT exitosa:", respuesta.data);
          var tipo = respuesta.data[0];
          var msj = respuesta.data[1];
          show_alert("Cargo editado con éxito", "success");
          document.getElementById("btnCerrar").click();
          getCandidatoEstudiante();
        })
        .catch(function (error) {
          show_alert("Error de solucitud", "error");
          console.log(error);
        });
    }
  };


  const deleteCandidatoEstudiante = (candidatoEstudianteId, nombre) => {
    const MySwal = withReactContent(Swal);
    MySwal.fire({
      title: "¿Seguro quieres eliminar el cargo " + nombre + "?",
      icon: "question",
      text: "No se podra dar marcha atras",
      showCancelButton: true,
      confirmButtonText: "Si, eliminar",
      cancelButtonText: "Cancelar",
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await axios.delete(`${url}/${candidatoEstudianteId}`);
          show_alert("Usuario eliminado exitosamente", "success");
          getCandidatoEstudiante();
        } catch (error) {
          show_alert("Error al eliminar al estudiante", "error");
          console.error(error);
        }
      } else {
        show_alert("El estudiante no fue eliminado", "info");
      }
    });
  };

  return (
    <div className="App">
      <div className="container-fluid">
        <div className="row mt-3">
          <div className="col-md-4 offset-4">
            <div className="d-gris mx-auto">
            <div className="d-flex justify-content-center align-items-center h-100">
              <button
                onClick={() => openModal(1)}
                className="btn btn-primary"
                data-bs-toggle="modal"
                data-bs-target="#modalCandidatoEstudiante"
              >
                <i className="fa-solid fa-circle-plus"></i> Añadir Estudiante nuevo
              </button>
              </div>
            </div>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-12 col-lg-8 offset-0 offset-lg-2">
            <div className="table-responsive">
              <table className="table table-bordered">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>ESTUDIANTEID</th>
                    <th>NOMBRE</th>
                    <th>APELLIDO</th>
                    <th>UPDATE/DELETE</th>
                  </tr>
                </thead>
                <tbody className="table-group-divider">
                  {candidatoEstudiante.map((CandidatoEstudiante, i) => (
                    <tr key={CandidatoEstudiante.candidatoEstudianteId}>
                      <td>{i + 1}</td>
                      <td>{CandidatoEstudiante.candidatoEstudianteId}</td>
                      <td>{CandidatoEstudiante.nombre}</td>
                      <td>{CandidatoEstudiante.apellido}</td>

                      <td>
                        <button onClick={() => openModal(2, CandidatoEstudiante)} className="btn btn-warning" data-bs-toggle='modal' data-bs-target='#modalCandidatoEstudiante'>
                          <i className="fa-solid fa-edit"></i>
                        </button>
                        &nbsp;
                        <button onClick={() => deleteCandidatoEstudiante(CandidatoEstudiante.candidatoEstudianteId, CandidatoEstudiante.nombre, CandidatoEstudiante.apellido)} className="btn btn-danger">
                          <i className="fa-solid fa-trash"></i>
                        </button>

                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <div id="modalCandidatoEstudiante" className="modal fade" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <label className="h5">{title}</label>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div className="modal-body">
              <input type="hidden" id="candidatoEstudianteId" />
              <div className="input-group mb-3">
                
                
              </div>
                    <div className="input-group mb-3">
                    <span className="input-group-text"><i className="fa-solid fa-comment"></i></span>
                    <input
                        type="text"
                        id="Nombre"
                        className="form-control"
                        placeholder="NOMBRE"
                        value={nombre}
                        onChange={(e) => setNombre(e.target.value)}
                      />
                    </div>
                    <div className="input-group mb-3">
                      <span className="input-group-text"><i className="fa-solid fa-comment"></i></span>
                      <input
                        type="text"
                        id="Apellido"
                        className="form-control"
                        placeholder="APELLIDO"
                        value={apellido}
                        onChange={(e) => setApellido(e.target.value)}
                      />
                    </div>
                    <div className='d-grid col-6 mx-auto'>
                    <div className="d-flex justify-content-center align-items-center h-100">
                      <button onClick={() => validar()} className='btn btn-success'>Guardar</button>
                    </div>
                    </div>
                  </div>
                  <div className='modal-footer'>
                  <div className="d-flex justify-content-center align-items-center h-100">
                    <button type='button' id="btnCerrar" className='btn btn-secondary' data-bs-dismiss='modal'>Cerrar</button>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      };
      
      export default CandidatoEstudiante;