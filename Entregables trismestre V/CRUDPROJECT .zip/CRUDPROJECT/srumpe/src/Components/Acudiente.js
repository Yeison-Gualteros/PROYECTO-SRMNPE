import React, { useEffect, useState } from 'react';
import '../Estilos.css';
import axios from 'axios';
import { show_alert } from '../functions';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';

const Acudiente = () => {
  const url = 'https://localhost:5001/api/acudiente';
  const [acudientes, setAcudientes] = useState([]);
  const [acudienteId, setAcudienteId] = useState('');
  const [nombres, setNombres] = useState('');
  const [apellidos, setApellidos] = useState('');
  const [numeroIdentificacion, setNumeroIdentificacion] = useState('');
  const [genero, setGenero] = useState('');
  const [fechaNacimiento, setFechaNacimiento] = useState('');
  const [correoElectronico, setCorreoElectronico] = useState('');
  const [relacionConEstudiante, setRelacionConEstudiante] = useState('');
  const [operation, setOperation] = useState(1);
  const [title, setTitle] = useState('');

  useEffect(() => {
    getAcudientes();
  }, []);

  const getAcudientes = async () => {
    try {
      const response = await axios.get(url);
      setAcudientes(response.data);
    } catch (error) {
      console.error('Error al obtener acudientes:', error);
    }
  };

  const openModal = (op, acudiente) => {
    setOperation(op);
    if (op === 1) {
      setTitle('Registrar Acudiente');
      setAcudienteId('');
      setNombres('');
      setApellidos('');
      setNumeroIdentificacion('');
      setGenero('');
      setFechaNacimiento('');
      setCorreoElectronico('');
      setRelacionConEstudiante('');
    } else if (op === 2) {
      setTitle('Editar Acudiente');
      setAcudienteId(acudiente.acudienteId);
      setNombres(acudiente.nombres);
      setApellidos(acudiente.apellidos);
      setNumeroIdentificacion(acudiente.numeroIdentificacion);
      setGenero(acudiente.genero);
      setFechaNacimiento(acudiente.fechaNacimiento);
      setCorreoElectronico(acudiente.correoElectronico);
      setRelacionConEstudiante(acudiente.relacionConEstudiante);
    }
  };

  const validar = () => {
    if (nombres.trim() === '') {
      show_alert('Escribe el nombre del acudiente', 'Escribe el nombre del acudiente');
    } else if (apellidos.trim() === '') {
      show_alert('Escribe el apellido del acudiente', 'Escribe el apellido del acudiente');
    } else if (numeroIdentificacion === '') {
      show_alert('Escribe el número de identificación del acudiente', 'Escribe el número de identificación del acudiente');
    } else if (genero.trim() === '') {
      show_alert('Escribe el género del acudiente', 'Escribe el género del acudiente');
    } else if (fechaNacimiento.trim() === '') {
      show_alert('Escribe la fecha de nacimiento del acudiente', 'Escribe la fecha de nacimiento del acudiente');
    } else if (correoElectronico.trim() === '') {
      show_alert('Escribe el correo electrónico del acudiente', 'Escribe el correo electrónico del acudiente');
    } else if (relacionConEstudiante.trim() === '') {
      show_alert('¿Cuál es la relación con el estudiante?', '¿Cuál es la relación con el estudiante?');
    } else {
      const parametros = {
        nombres,
        apellidos,
        numeroIdentificacion,
        genero,
        fechaNacimiento,
        correoElectronico,
        relacionConEstudiante,
      };
      const metodo = operation === 1 ? 'POST' : 'PUT';
      enviarSolicitud(metodo, parametros);
    }
  };

  const enviarSolicitud = async (metodo, parametros) => {
    try {
      const response = await (metodo === 'POST'
        ? axios.post(url, parametros)
        : axios.put(`${url}/${acudienteId}`, parametros));
  
      if (response.data) {
        show_alert('Operación exitosa', 'success');
        document.getElementById('btnCerrar').click();
        getAcudientes();
      } else {
        show_alert('Error en la solicitud', 'error');
      }
    } catch (error) {
      show_alert('Error en la solicitud', 'error');
      console.error(error);
    }
  };

  const deleteAcudiente = (acudienteId, nombres) => {
    const MySwal = withReactContent(Swal);
    MySwal.fire({
      title: `¿Seguro quieres eliminar al acudiente ${nombres}?`,
      icon: 'question',
      text: 'No se podrá dar marcha atrás',
      showCancelButton: true,
      confirmButtonText: 'Si, eliminar',
      cancelButtonText: 'Cancelar',
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await axios.delete(`${url}/${acudienteId}`);
          show_alert('Acudiente eliminado exitosamente', 'success');
          getAcudientes();
        } catch (error) {
          show_alert('Error al eliminar al acudiente', 'error');
          console.error(error);
        }
      } else {
        show_alert('El acudiente no fue eliminado', 'info');
      }
    });
  };

  return (
    <div className="App">
      <div className="container-fluid">
        <div className="row mt-3">
          <div className="col-md-4 offset-4">
            <div className="d-gris mx-auto">
              <div className="d-flex justify-content-center align-items-center h-100">
                <button
                  onClick={() => openModal(1)}
                  className="btn btn-primary"
                  data-bs-toggle="modal"
                  data-bs-target="#modalAcudiente"
                >
                  <i className="fa-solid fa-circle-plus"></i> Añadir Acudiente nuevo
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-12 col-lg-8 offset-0 offset-lg-2">
            <div className="table-responsive">
              <table className="table table-bordered">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>ACUDIENTEID</th>
                    <th>NOMBRE</th>
                    <th>APELLIDO</th>
                    <th>NUMERO DE IDENTIFICACION</th>
                    <th>GENERO</th>
                    <th>FECHA DE NACIMIENTO</th>
                    <th>CORREO ELECTRONICO</th>
                    <th>RELACION CON EL ESTUDIANTE</th>
                    <th>UPDATE/DELETE</th>
                  </tr>
                </thead>
                <tbody className="table-group-divider">
                  {acudientes.map((acudiente, i) => (
                    <tr key={acudiente.acudienteId}>
                      <td>{i + 1}</td>
                      <td>{acudiente.acudienteId}</td>
                      <td>{acudiente.nombres}</td>
                      <td>{acudiente.apellidos}</td>
                      <td>{acudiente.numeroIdentificacion}</td>
                      <td>{acudiente.genero}</td>
                      <td>{acudiente.fechaNacimiento}</td>
                      <td>{acudiente.correoElectronico}</td>
                      <td>{acudiente.relacionConEstudiante}</td>
                      <td>
                        <button
                          onClick={() => openModal(2, acudiente)}
                          className="btn btn-warning"
                          data-bs-toggle="modal"
                          data-bs-target="#modalAcudiente"
                        >
                          <i className="fa-solid fa-edit"></i>
                        </button>
                        &nbsp;
                        <button
                          onClick={() => deleteAcudiente(acudiente.acudienteId, acudiente.nombres)}
                          className="btn btn-danger"
                        >
                          <i className="fa-solid fa-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <div id="modalAcudiente" className="modal fade" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">{title}</h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <input type="hidden" id="acudienteId" />
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="Nombres"
                  className="form-control"
                  placeholder="NOMBRE"
                  value={nombres}
                  onChange={(e) => setNombres(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="Apellidos"
                  className="form-control"
                  placeholder="APELLIDO"
                  value={apellidos}
                  onChange={(e) => setApellidos(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="NumeroIdentificacion"
                  className="form-control"
                  placeholder="NUMERO DE IDENTIFICACION"
                  value={numeroIdentificacion}
                  onChange={(e) => setNumeroIdentificacion(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="Genero"
                  className="form-control"
                  placeholder="GENERO"
                  value={genero}
                  onChange={(e) => setGenero(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="FechaNacimiento"
                  className="form-control"
                  placeholder="FECHA DE NACIMIENTO"
                  value={fechaNacimiento}
                  onChange={(e) => setFechaNacimiento(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="CorreoElectronico"
                  className="form-control"
                  placeholder="CORREO ELECTRONICO"
                  value={correoElectronico}
                  onChange={(e) => setCorreoElectronico(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="RelacionConEstudiante"
                  className="form-control"
                  placeholder="RELACION CON EL ESTUDIANTE"
                  value={relacionConEstudiante}
                  onChange={(e) => setRelacionConEstudiante(e.target.value)}
                />
              </div>
              <div className="d-grid col-6 mx-auto">
                <div className="d-flex justify-content-center align-items-center h-100">
                  <button onClick={() => validar()} className="btn btn-success">
                    Guardar
                  </button>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <div className="d-flex justify-content-center align-items-center h-100">
                <button
                  type="button"
                  id="btnCerrar"
                  className="btn btn-secondary"
                  data-bs-dismiss="modal"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Acudiente;