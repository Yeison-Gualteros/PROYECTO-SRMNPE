import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Swal from 'sweetalert2';
import { show_alert } from '../functions';
import withReactContent from 'sweetalert2-react-content';

const Horarios = () => {
  const url = 'https://localhost:5001/api/horario';
  const [horarios, setHorarios] = useState([]);
  const [horarioId, setHorarioId] = useState('');
  const [diaSemana, setDiaSemana] = useState('');
  const [horaInicio, setHoraInicio] = useState('');
  const [horaFin, setHoraFin] = useState('');
  const [periodoAcademico, setPeriodoAcademico] = useState('');
  const [grupoSeccion, setGrupoSeccion] = useState('');
  const [operation, setOperation] = useState(1);
  const [title, setTitle] = useState('');

  useEffect(() => {
    getHorarios();
  }, []);

  const getHorarios = async () => {
    try {
      const response = await axios.get(url);
      setHorarios(response.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const openModal = (op, horario) => {
    setOperation(op);
    if (op === 1) {
      setTitle('Registrar Horario');
      // Clear form inputs
      setHorarioId('');
      setDiaSemana('');
      setHoraInicio('');
      setHoraFin('');
      setPeriodoAcademico('');
      setGrupoSeccion('');
    } else if (op === 2) {
      setTitle('Editar Horario');
      setHorarioId(horario.horarioId);
      setDiaSemana(horario.diaSemana);
      setHoraInicio(horario.horaInicio);
      setHoraFin(horario.horaFin);
      setPeriodoAcademico(horario.periodoAcademico);
      setGrupoSeccion(horario.grupoSeccion);
    }
  };

  const validar = () => {
    const validationChecks = [
      { value: diaSemana, message: 'Escribe el día de la semana' },
      { value: horaInicio, message: 'Escribe la hora de inicio' },
      { value: horaFin, message: 'Escribe la hora de fin' },
      { value: periodoAcademico, message: 'Escribe el periodo académico' },
      { value: grupoSeccion, message: 'Escribe el grupo/sección' },
    ];

    for (const check of validationChecks) {
      if (check.value.trim() === '') {
        show_alert(check.message, 'Campo obligatorio');
        return;
      }
    }

    const parametros = {
      diaSemana,
      horaInicio,
      horaFin,
      periodoAcademico,
      grupoSeccion,
    };

    const metodo = operation === 1 ? 'POST' : 'PUT';
    enviarSolicitud(metodo, parametros);
  };

  const enviarSolicitud = async (metodo, parametros) => {
    try {
      const response =
        metodo === 'POST'
          ? await axios.post(url, parametros)
          : await axios.put(`${url}/${horarioId}`, parametros);

      show_alert(
        metodo === 'POST'
          ? 'Horario añadido exitosamente'
          : 'Horario editado con éxito',
        'success'
      );

      document.getElementById('btnCerrar').click();
      getHorarios();
    } catch (error) {
      show_alert('Error de solicitud', 'error');
      console.error(error);
    }
  };

  const deleteHorarios = (horarioId, diaSemana) => {
    const MySwal = withReactContent(Swal);
    MySwal.fire({
      title: `¿Seguro quieres eliminar el horario del día ${diaSemana}?`,
      icon: 'question',
      text: 'No se podrá dar marcha atrás',
      showCancelButton: true,
      confirmButtonText: 'Si, eliminar',
      cancelButtonText: 'Cancelar',
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await axios.delete(`${url}/${horarioId}`);
          show_alert('Horario eliminado exitosamente', 'success');
          getHorarios();
        } catch (error) {
          show_alert('Error al eliminar el Horario', 'error');
          console.error(error);
        }
      } else {
        show_alert('El Horario no fue eliminado', 'info');
      }
    });
  };

  return (
    <div className="App">
      <div className="container-fluid">
        <div className="row mt-3">
          <div className="col-md-4 offset-4">
            <div className="d-gris mx-auto">
            <div className="d-flex justify-content-center align-items-center h-100">
              <button
                onClick={() => openModal(1)}
                className="btn btn-primary"
                data-bs-toggle="modal"
                data-bs-target="#modalHorarios"
              >
                <i className="fa-solid fa-circle-plus"></i> Añadir Horario nuevo
              </button>
              </div>
            </div>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-12 col-lg-8 offset-0 offset-lg-2">
            <div className="table-responsive">
              <table className="table table-bordered">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>HORARIOID</th>
                    <th>DIA DE LA SEMANA</th>
                    <th>HORARIO INICIO</th>
                    <th>HORARIO FIN</th>
                    <th>PERIODO ACADEMICO</th>
                    <th>GRUPO DE SELECCION</th>
                    <th>UPDATE/DELETE</th>
                  </tr>
                </thead>
                <tbody className="table-group-divider">
                  {horarios.map((horarios, i) => (
                    <tr key={horarios.horarioId}>
                      <td>{i + 1}</td>
                      <td>{horarios.horarioId}</td>
                      <td>{horarios.diaSemana}</td>
                      <td>{horarios.horaInicio}</td>
                      <td>{horarios.horaFin}</td>
                      <td>{horarios.periodoAcademico}</td>
                      <td>{horarios.grupoSeccion}</td>

                      <td>
                        <button onClick={() => openModal(2, horarios)} className="btn btn-warning" data-bs-toggle='modal' data-bs-target='#modalHorarios'>
                          <i className="fa-solid fa-edit"></i>
                        </button>
                        &nbsp;
                        <button onClick={() => deleteHorarios(horarios.horarioId, horarios.grupoSeccion)} className="btn btn-danger">
                          <i className="fa-solid fa-trash"></i>
                        </button>

                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <div id="modalHorarios" className="modal fade" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <label className="h5">{title}</label>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div className="modal-body">
              <input type="hidden" id="horarioId" />
              <div className="input-group mb-3">
                
                
              </div>
                    <div className="input-group mb-3">
                    <span className="input-group-text"><i className="fa-solid fa-comment"></i></span>
                    <input
                        type="text"
                        id="DiaSemana"
                        className="form-control"
                        placeholder="DIA DE LA SEMANA"
                        value={diaSemana}
                        onChange={(e) => setDiaSemana(e.target.value)}
                      />
                    </div>
                    <div className="input-group mb-3">
                      <span className="input-group-text"><i className="fa-solid fa-comment"></i></span>
                      <input
                        type="text"
                        id="HoraInicio"
                        className="form-control"
                        placeholder="HORA DE INICIO"
                        value={horaInicio}
                        onChange={(e) => setHoraInicio(e.target.value)}
                      />
                    </div>

                    <div className="input-group mb-3">
                      <span className="input-group-text"><i className="fa-solid fa-comment"></i></span>
                      <input
                        type="text"
                        id="HoraFin"
                        className="form-control"
                        placeholder="HORA DE FIN"
                        value={horaFin}
                        onChange={(e) => setHoraFin(e.target.value)}
                      />
                    </div>
                    <div className="input-group mb-3">
                      <span className="input-group-text"><i className="fa-solid fa-comment"></i></span>
                      <input
                        type="text"
                        id="PeriodoAcademico"
                        className="form-control"
                        placeholder="PERIODO ACADEMICO"
                        value={periodoAcademico}
                        onChange={(e) => setPeriodoAcademico(e.target.value)}
                      />
                    </div>
                    <div className="input-group mb-3">
                      <span className="input-group-text"><i className="fa-solid fa-comment"></i></span>
                      <input
                        type="text"
                        id="GrupoSeccion"
                        className="form-control"
                        placeholder="GRUPO DE SELECCION"
                        value={grupoSeccion}
                        onChange={(e) => setGrupoSeccion(e.target.value)}
                      />
                    </div>
                    <div className='d-grid col-6 mx-auto'>
                    <div className="d-flex justify-content-center align-items-center h-100">
                      <button onClick={() => validar()} className='btn btn-success'>Guardar</button>
                    </div>
                    </div>
                  </div>
                  <div className='modal-footer'>
                  <div className="d-flex justify-content-center align-items-center h-100">
                    <button type='button' id="btnCerrar" className='btn btn-secondary' data-bs-dismiss='modal'>Cerrar</button>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      };
      
      export default Horarios;