import React, { useEffect, useState } from 'react';
import '../Estilos.css';
import axios from 'axios';
//import { show_alert } from '../functions';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';

const Cupo = () => {
  const url = 'https://localhost:5001/api/Cupo';
  const [cupo, setCupo] = useState([]);
  const [cupoId, setCupoId] = useState('');
  const [cantidadDisponible, setCantidadDisponible] = useState('');
  const [fechaInicio, setFechaInicio] = useState('');
  const [fechaFin, setFechaFin] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [ubicacion, setUbicacion] = useState('');
  const [duracion, setDuracion] = useState('');
  const [operation, setOperation] = useState(1); 
  const [title, setTitle] = useState('');

  useEffect(() => {
    getCupo();
  }, []);

  const getCupo = async () => {
    try {
      const respuesta = await axios.get(url);
      setCupo(respuesta.data);
    } catch (error) {
      console.error(error);
    }
  };

  const openModal = (op, cupo) => {
    setOperation(op); // Corrected the state variable name
    if (op === 1) {
      setTitle('Registrar Cupo'); // Corrected the title
      setCupoId('');
      setCantidadDisponible('');
      setFechaInicio('');
      setFechaFin('');
      setDescripcion('');
      setUbicacion('');
      setDuracion('');
    } else if (op === 2) {
      setTitle('Editar Cupo'); // Corrected the title
      setCupoId(cupo.cupoId);
      setCantidadDisponible(cupo.cantidadDisponible);
      setFechaInicio(cupo.fechaInicio);
      setFechaFin(cupo.fechaFin);
      setDescripcion(cupo.descripcion);
      setUbicacion(cupo.ubicacion);
      setDuracion(cupo.duracion);
    }
  };

  const validar = () => {
    if (cantidadDisponible === '') {
      mostrarAlerta('Escribe la cantidad disponible');
    } else if (fechaInicio.trim() === '') {
      mostrarAlerta('Escribe la fecha de inicio');
    } else if (fechaFin.trim() === '') {
      mostrarAlerta('Escribe la fecha de fin');
    } else if (descripcion.trim() === '') {
      mostrarAlerta('Escribe la descripción');
    } else if (ubicacion.trim() === '') {
      mostrarAlerta('Escribe la ubicación');
    } else if (duracion.trim() === '') {
      mostrarAlerta('Escribe la duración');
    } else {
      let parametros;
      let metodo;

      if (operation === 1) {
        parametros = {
          cantidadDisponible: cantidadDisponible,
          fechaInicio: fechaInicio,
          fechaFin: fechaFin,
          descripcion: descripcion,
          ubicacion: ubicacion,
          duracion: duracion,
        };
        metodo = 'POST';
      } else {
        parametros = {
          cantidadDisponible: cantidadDisponible,
          fechaInicio: fechaInicio,
          fechaFin: fechaFin,
          descripcion: descripcion,
          ubicacion: ubicacion,
          duracion: duracion,
        };
        metodo = 'PUT';
      }

      enviarSolicitud(metodo, parametros);
    }
  };

  const enviarSolicitud = async (metodo, parametros) => {
    try {
      let respuesta;
      if (metodo === 'POST') {
        respuesta = await axios.post(url, parametros);
        mostrarAlerta('Cupo añadido exitosamente', 'success');
      } else if (metodo === 'PUT') {
        respuesta = await axios.put(`${url}/${cupoId}`, parametros);
        mostrarAlerta('Cupo editado exitosamente', 'success');
      }
      document.getElementById('btnCerrar').click();
      getCupo();
    } catch (error) {
      mostrarAlerta('Error de solicitud', 'error');
      console.error(error);
    }
  };

  const deleteCupo = (cupoId, ubicacion) => {
    const MySwal = withReactContent(Swal);
    MySwal.fire({
      title: `¿Seguro quieres eliminar el cupo de ${ubicacion}?`,
      icon: 'question',
      text: 'No se podrá deshacer',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await axios.delete(`${url}/${cupoId}`);
          mostrarAlerta('Cupo eliminado exitosamente', 'success');
          getCupo();
        } catch (error) {
          mostrarAlerta('Error al eliminar el cupo', 'error');
          console.error(error);
        }
      } else {
        mostrarAlerta('El cupo no fue eliminado', 'info');
      }
    });
  };

  const mostrarAlerta = (mensaje, tipo) => {
    Swal.fire({
      title: mensaje,
      icon: tipo,
    });
  };
  return (
    <div className="App">
      <div className="container-fluid">
        <div className="row mt-3">
          <div className="col-md-4 offset-4">
            <div className="d-gris mx-auto">
              <div className="d-flex justify-content-center align-items-center h-100">
                <button
                  onClick={() => openModal(1)}
                  className="btn btn-primary"
                  data-bs-toggle="modal"
                  data-bs-target="#modalCupo"
                >
                  <i className="fa-solid fa-circle-plus"></i> Añadir Cupo nuevo
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-12 col-lg-8 offset-0 offset-lg-2">
            <div className="table-responsive">
              <table className="table table-bordered">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>CUPOID</th>
                    <th>CANTIDAD DISPONIBLE</th>
                    <th>FECHA DE INICIO</th>
                    <th>FECHA DE FIN</th>
                    <th>DESCRIPCION</th>
                    <th>UBICACION</th>
                    <th>APELLIDO</th>
                    <th>DURACION</th>
                    <th>UPDATE/DELETE</th>
                  </tr>
                </thead>
                <tbody className="table-group-divider">
                  {cupo.map((cupoItem, i) => (
                    <tr key={cupoItem.cupoId}> 
                       <td>{i + 1}</td>
                      <td>{cupoItem.cupoId}</td> {/* Display the correct property */}
                      <td>{cupoItem.cantidadDisponible}</td> {/* Display the correct property */}
                      <td>{cupoItem.fechaInicio}</td> {/* Display the correct property */}
                      <td>{cupoItem.fechaFin}</td> {/* Display the correct property */}
                      <td>{cupoItem.descripcion}</td> {/* Display the correct property */}
                      <td>{cupoItem.ubicacion}</td> {/* Display the correct property */}
                      <td>{cupoItem.apellido}</td> {/* Display the correct property */}
                      <td>{cupoItem.duracion}</td> {/* Display the correct property */}
                      <td>
                        <button
                          onClick={() => openModal(2, cupoItem)}
                          className="btn btn-warning"
                          data-bs-toggle="modal"
                          data-bs-target="#modalCupo"
                        >
                          <i className="fa-solid fa-edit"></i>
                        </button>
                        &nbsp;
                        <button
                          onClick={() => deleteCupo(cupoItem.cupoId, cupoItem.ubicacion)}
                          className="btn btn-danger"
                        >
                          <i className="fa-solid fa-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <div id="modalCupo" className="modal fade" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">{title}</h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <input type="hidden" id="cupoId" />
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="CantidadDisponible"
                  className="form-control"
                  placeholder="CANTIDAD DISPONIBLE"
                  value={cantidadDisponible}
                  onChange={(e) => setCantidadDisponible(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="FechaInicio"
                  className="form-control"
                  placeholder="FECHA DE INICIO"
                  value={fechaInicio}
                  onChange={(e) => setFechaInicio(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="FechaFin"
                  className="form-control"
                  placeholder="FECHA DE FIN"
                  value={fechaFin}
                  onChange={(e) => setFechaFin(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="Descripcion"
                  className="form-control"
                  placeholder="DESCRIPCION"
                  value={descripcion}
                  onChange={(e) => setDescripcion(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="Ubicacion"
                  className="form-control"
                  placeholder="UBICACION"
                  value={ubicacion}
                  onChange={(e) => setUbicacion(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="Duracion"
                  className="form-control"
                  placeholder="DURACION"
                  value={duracion}
                  onChange={(e) => setDuracion(e.target.value)}
                />
              </div>
              <div className="d-grid col-6 mx-auto">
                <button onClick={() => validar()} className="btn btn-success">
                  Guardar
                </button>
              </div>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                id="btnCerrar"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cupo;