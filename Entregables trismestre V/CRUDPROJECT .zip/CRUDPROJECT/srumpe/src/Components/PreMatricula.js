import React, { useEffect, useState } from 'react';
import '../Estilos.css';
import axios from 'axios';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';

const PreMatricula = () => {
  const url = 'https://localhost:5001/api/preMatricula';
  const [preMatricula, setPreMatricula] = useState([]);
  const [preMatriculaId, setPreMatriculaId] = useState('');
  const [gradoONivel, setGradoONivel] = useState('');
  const [turno, setTurno] = useState('');
  const [observaciones, setObservaciones] = useState('');
  const [requisitosDocumentacion, setRequisitosDocumentacion] = useState('');
  const [operation, setOperation] = useState(1);
  const [title, setTitle] = useState('');
  const URL = `https://localhost:5001/api/preMatricula/${preMatriculaId}`

  useEffect(() => {
    getPreMatricula();
  }, []);

  const getPreMatricula = async () => {
    try {
      const respuesta = await axios.get(url);
      setPreMatricula(respuesta.data);
    } catch (error) {
      console.error(error);
    }
  };

  const openModal = (op, preMatriculaItem) => {
    setOperation(op);
    if (op === 1) {
      setTitle('Registrar prematricula');
      setPreMatriculaId('');
      setGradoONivel('');
      setTurno('');
      setObservaciones('');
      setRequisitosDocumentacion('');
    } else if (op === 2) {
      setTitle('Editar Cupo');
      setPreMatriculaId(preMatriculaItem.preMatriculaId);
      setGradoONivel(preMatriculaItem.gradoONivel);
      setTurno(preMatriculaItem.turno);
      setObservaciones(preMatriculaItem.observaciones);
      setRequisitosDocumentacion(preMatriculaItem.requisitosDocumentacion);
    }
  };

  const validar = () => {
    if (gradoONivel === '') {
      mostrarAlerta('Escribe grado o nivel disponible');
    } else if (turno.trim() === '') {
      mostrarAlerta('Escribe el turno');
    } else if (observaciones.trim() === '') {
      mostrarAlerta('Escribe las observaciones');
    } else if (requisitosDocumentacion.trim() === '') {
      mostrarAlerta('Escriba los documentos del documento');
    } else {
      let parametros;
      let metodo;

      if (operation === 1) {
        parametros = {
          gradoONivel: gradoONivel,
          turno: turno,
          observaciones: observaciones,
          requisitosDocumentacion: requisitosDocumentacion,
        };
        metodo = 'POST';
      } else {
        parametros = {
          gradoONivel: gradoONivel,
          turno: turno,
          observaciones: observaciones,
          requisitosDocumentacion: requisitosDocumentacion,
        };
        metodo = 'PUT';
      }

      enviarSolicitud(metodo, parametros);
    }
  };

  const enviarSolicitud = async (metodo, parametros) => {
    try {
      let respuesta;
      if (metodo === 'POST') {
        respuesta = await axios.post(`${URL}`, parametros);
        mostrarAlerta('prematricula añadida exitosamente', 'success');
      } else if (metodo === 'PUT') {
        respuesta = await axios.put(`${URL}`, parametros);
        mostrarAlerta('prematricula editada exitosamente', 'success');
      }
      document.getElementById('btnCerrar').click();
      getPreMatricula();
    } catch (error) {
      mostrarAlerta('Error de solicitud', 'error');
    }
  };

  const deletePreMatricula = (preMatriculaId, turno) => {
    const MySwal = withReactContent(Swal);
    MySwal.fire({
      title: `¿Seguro quieres eliminar el turno ${turno}?`,
      icon: 'question',
      text: 'No se podrá deshacer',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await axios.delete(`${URL}/${preMatriculaId}`);
          mostrarAlerta('prematricula eliminada exitosamente', 'success');
          getPreMatricula();
        } catch (error) {
          mostrarAlerta('Error al eliminar la prematricula', 'error');
          console.error(error);
        }
      } else {
        mostrarAlerta('la prematricula no fue eliminada', 'info');
      }
    });
  };

  const mostrarAlerta = (mensaje, tipo) => {
    Swal.fire({
      title: mensaje,
      icon: tipo,
    });
  };
  return (
    <div className="App">
      <div className="container-fluid">
        <div className="row mt-3">
          <div className="col-md-4 offset-4">
            <div className="d-gris mx-auto">
              <div className="d-flex justify-content-center align-items-center h-100">
                <button
                  onClick={() => openModal(1)}
                  className="btn btn-primary"
                  data-bs-toggle="modal"
                  data-bs-target="#modalPreMatricula"
                >
                  <i className="fa-solid fa-circle-plus"></i> Añadir prematricula nueva
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-12 col-lg-8 offset-0 offset-lg-2">
            <div className="table-responsive">
              <table className="table table-bordered">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>PREMATRICULAID</th>
                    <th>GRADO O NIVEL</th>
                    <th>TURNO</th>
                    <th>OBSERVACIONES</th>
                    <th>REQUISITOS DOCUMENTOS</th>
                    <th>UPDATE/DELETE</th>
                  </tr>
                </thead>
                <tbody className="table-group-divider">
                  {preMatricula.map((preMatriculaItem, i) => (
                    <tr key={preMatriculaItem.preMatriculaId}>
                      <td>{i + 1}</td>
                      <td>{preMatriculaItem.preMatriculaId}</td>
                      <td>{preMatriculaItem.gradoONivel}</td>
                      <td>{preMatriculaItem.turno}</td>
                      <td>{preMatriculaItem.observaciones}</td>
                      <td>{preMatriculaItem.requisitosDocumentacion}</td>
                      <td>
                        <button
                          onClick={() => openModal(2, preMatriculaItem)}
                          className="btn btn-warning"
                          data-bs-toggle="modal"
                          data-bs-target="#modalPreMatricula"
                        >
                          <i className="fa-solid fa-edit"></i>
                        </button>
                        &nbsp;
                        <button
                          onClick={() => deletePreMatricula(preMatriculaItem.preMatriculaId, preMatriculaItem.turno)}
                          className="btn btn-danger"
                        >
                          <i className="fa-solid fa-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <div id="modalPreMatricula" className="modal fade" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">{title}</h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <input type="hidden" id="preMatriculaId" />
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="GradoONivel"
                  className="form-control"
                  placeholder="GRADO O NIVEL"
                  value={gradoONivel}
                  onChange={(e) => setGradoONivel(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="Turno"
                  className="form-control"
                  placeholder="TURNO"
                  value={turno}
                  onChange={(e) => setTurno(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="Observaciones"
                  className="form-control"
                  placeholder="OBSERVACIONES"
                  value={observaciones}
                  onChange={(e) => setObservaciones(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="RequisitosDocumentacion"
                  className="form-control"
                  placeholder="REQUISITOS DE DOCUMENTACION"
                  value={requisitosDocumentacion}
                  onChange={(e) => setRequisitosDocumentacion(e.target.value)}
                />
              </div>
              <div className="d-grid col-6 mx-auto">
                <button onClick={() => validar()} className="btn btn-success">
                  Guardar
                </button>
              </div>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                id="btnCerrar"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PreMatricula;