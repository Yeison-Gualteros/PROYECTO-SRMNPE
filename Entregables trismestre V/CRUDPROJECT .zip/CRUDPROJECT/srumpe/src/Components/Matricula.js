import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';

const Matricula = () => {
  const url = 'https://localhost:5001/api/matricula';
  const [matricula, setMatricula] = useState([]);
  const [matriculaId, setMatriculaId] = useState('');
  const [fechaMatricula, setFechaMatricula] = useState('');
  const [estadoMatricula, setEstadoMatricula] = useState('');
  const [tipoMatricula, setTipoMatricula] = useState('');
  const [periodoAcademico, setPeriodoAcademico] = useState('');
  const [registroCambios, setRegistroCambios] = useState('');
  const [operation, setOperation] = useState(1);
  const [title, setTitle] = useState('');

  useEffect(() => {
    getMatricula();
  }, []);

  const getMatricula = async () => {
    try {
      const respuesta = await axios.get(url);
      setMatricula(respuesta.data);
    } catch (error) {
      console.error(error);
    }
  };

  const openModal = (op, matriculaItem) => {
    setOperation(op);
    if (op === 1) {
      setTitle('Registrar Matrícula');
      resetForm();
    } else if (op === 2 && matriculaItem) {
      setTitle('Editar Matrícula');
      setMatriculaId(matriculaItem.matriculaId);
      setFechaMatricula(matriculaItem.fechaMatricula);
      setEstadoMatricula(matriculaItem.estadoMatricula);
      setTipoMatricula(matriculaItem.tipoMatricula);
      setPeriodoAcademico(matriculaItem.periodoAcademico);
      setRegistroCambios(matriculaItem.registroCambios);
    }
  };

  const resetForm = () => {
    setMatriculaId('');
    setFechaMatricula('');
    setEstadoMatricula('');
    setTipoMatricula('');
    setPeriodoAcademico('');
    setRegistroCambios('');
  };

  const validar = () => {
    if (!fechaMatricula || !estadoMatricula || !tipoMatricula || !periodoAcademico || !registroCambios) {
      mostrarAlerta('Por favor, completa todos los campos', 'error');
    } else {
      const parametros = {
        matriculaId: matriculaId,
        fechaMatricula: fechaMatricula,
        estadoMatricula: estadoMatricula,
        tipoMatricula: tipoMatricula,
        periodoAcademico: periodoAcademico,
        registroCambios: registroCambios,
      };

      const metodo = operation === 1 ? 'POST' : 'PUT';
      enviarSolicitud(metodo, parametros);
    }
  };

  const enviarSolicitud = async (metodo, parametros) => {
    try {
      let respuesta;
      if (metodo === 'POST') {
        respuesta = await axios.post(url, parametros);
        mostrarAlerta('Matrícula añadida exitosamente', 'success');
      } else if (metodo === 'PUT') {
        respuesta = await axios.put(`${url}/${matriculaId}`, parametros);
        mostrarAlerta('Matrícula editada exitosamente', 'success');
      }
      document.getElementById('btnCerrar').click();
      resetForm();
      getMatricula();
    } catch (error) {
      mostrarAlerta('Error de solicitud', 'error');
      console.error(error);
    }
  };

  const deleteMatricula = (matriculaId, registroCambios) => {
    const MySwal = withReactContent(Swal);
    MySwal.fire({
      title: `¿Seguro quieres eliminar la matrícula con registro de cambios: ${registroCambios}?`,
      icon: 'question',
      text: 'No se podrá deshacer',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await axios.delete(`${url}/${matriculaId}`);
          mostrarAlerta('Matrícula eliminada exitosamente', 'success');
          getMatricula();
        } catch (error) {
          mostrarAlerta('Error al eliminar la matrícula', 'error');
          console.error(error);
        }
      } else {
        mostrarAlerta('La matrícula no fue eliminada', 'info');
      }
    });
  };

  const mostrarAlerta = (mensaje, tipo) => {
    Swal.fire({
      title: mensaje,
      icon: tipo,
    });
  };
  return (
    <div className="App">
      <div className="container-fluid">
        <div className="row mt-3">
          <div className="col-md-4 offset-4">
            <div className="d-gris mx-auto">
              <div className="d-flex justify-content-center align-items-center h-100">
                <button
                  onClick={() => openModal(1)}
                  className="btn btn-primary"
                  data-bs-toggle="modal"
                  data-bs-target="#modalMatricula"
                >
                  <i className="fa-solid fa-circle-plus"></i> Añadir Matricula nueva
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-12 col-lg-8 offset-0 offset-lg-2">
            <div className="table-responsive">
              <table className="table table-bordered">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>MATRICULAID</th>
                    <th>FECHA DE LA MATRICULA</th>
                    <th>ESTADO DE LA MATRICULA</th>
                    <th>TIPO DE MATRICULA</th>
                    <th>PERIODO ACADEMICO</th>
                    <th>REGISTRO DE CAMBIOS</th>
                    <th>UPDATE/DELETE</th>
                  </tr>
                </thead>
                
                        <tbody className="table-group-divider">
        {matricula.map((matriculaItem, i) => (
            <tr key={matriculaItem.matriculaId}>
            <td>{i + 1}</td>
            <td>{matriculaItem.matriculaId}</td>
            <td>{matriculaItem.fechaMatricula}</td>
            <td>{matriculaItem.estadoMatricula}</td> 
            <td>{matriculaItem.tipoMatricula}</td> 
            <td>{matriculaItem.periodoAcademico}</td>
            <td>{matriculaItem.registroCambios}</td> 
            <td>
                <button
                onClick={() => openModal(2, matriculaItem)}
                className="btn btn-warning"
                data-bs-toggle="modal"
                data-bs-target="#modalMatricula"
                >
                <i className="fa-solid fa-edit"></i>
                </button>
                &nbsp;
                <button
                onClick={() => deleteMatricula(matriculaItem.matriculaId, matriculaItem.registroCambios)}
                className="btn btn-danger"
                >
                <i className="fa-solid fa-trash"></i>
                </button>
            </td>
            </tr>
        ))}
        </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <div id="modalMatricula" className="modal fade" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">{title}</h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <input type="hidden" id="cupoId" />
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="FechaMatricula"
                  className="form-control"
                  placeholder="FECHA DE LA MATRICULA"
                  value={fechaMatricula}
                  onChange={(e) => setFechaMatricula(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="EstadoMatricula"
                  className="form-control"
                  placeholder="ESTADO MATRICULA"
                  value={estadoMatricula}
                  onChange={(e) => setEstadoMatricula(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="TipoMatricula"
                  className="form-control"
                  placeholder="TIPO DE LA MATRICULA"
                  value={tipoMatricula}
                  onChange={(e) => setTipoMatricula(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="PeriodoAcademico"
                  className="form-control"
                  placeholder="PERIODO ACADEMICO"
                  value={periodoAcademico}
                  onChange={(e) => setPeriodoAcademico(e.target.value)}
                />
              </div>
              <div className="input-group mb-3">
                <span className="input-group-text">
                  <i className="fa-solid fa-comment"></i>
                </span>
                <input
                  type="text"
                  id="RegistroCambios"
                  className="form-control"
                  placeholder="REGISTRO DE LOS CAMBIOS"
                  value={registroCambios}
                  onChange={(e) => setRegistroCambios(e.target.value)}
                />
              </div>
              <div className="d-grid col-6 mx-auto">
                <button onClick={() => validar()} className="btn btn-success">
                  Guardar
                </button>
              </div>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                id="btnCerrar"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Matricula;